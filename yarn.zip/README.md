# React-Static - Blank Example

This example is a blank version of react-static. It includes::
- Babel
- CSS imports
- Image imports
- File imports

To get started, run `react-static create` and use the `blank` template.
