module.exports = {
  extends: 'react-tools',
}
